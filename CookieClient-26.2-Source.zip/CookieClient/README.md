# Cookie Client (Minecraft Java 26.2 / Fabric)

This is an initial source project, not a compiled or tested JAR. Press **Left Shift** to open the menu.

## Included in this starter build
- Left Shift menu with neon-blue title
- Toggle UI for Fullbright, coordinates HUD, armor alerts, mob outlines, ore highlighting, and Auto Totem

## Important status
The menu toggles are currently UI/configuration scaffolding. The gameplay effects (ore rendering, entity outlines, automatic offhand item handling, HUD drawing, and armor warnings) still need implementation and in-game testing. Do not treat a toggle showing ON as proof that its effect is active.

Use gameplay-affecting features only in private worlds or on servers where the owner explicitly allows them. This project does not include anti-cheat bypasses.

## Build
Requires JDK 25 and internet access to download Gradle/Fabric dependencies.

From this folder run:
- Windows: `gradlew.bat build` (after adding the Gradle wrapper)
- macOS/Linux: `gradle build`

The resulting mod JAR will be in `build/libs/`.

Toolchain targets Minecraft 26.2, Fabric Loader 0.19.3, Fabric API 0.161.0+26.2, Loom 1.17, and Gradle 9.5.1. Verify compatibility against the current Fabric develop page before building.
