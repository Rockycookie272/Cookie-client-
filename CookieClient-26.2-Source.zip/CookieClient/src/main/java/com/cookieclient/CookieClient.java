package com.cookieclient;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

public final class CookieClient implements ClientModInitializer {
    public static boolean fullbright = false;
    public static boolean coordsHud = true;
    public static boolean armorAlerts = true;
    public static boolean mobOutlines = false;
    public static boolean oreHighlight = false;
    public static boolean autoTotem = false;
    private static KeyMapping openMenu;

    @Override public void onInitializeClient() {
        openMenu = KeyBindingHelper.registerKeyBinding(new KeyMapping(
            "key.cookieclient.menu", GLFW.GLFW_KEY_LEFT_SHIFT,
            KeyMapping.Category.MISC));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenu.consumeClick()) client.setScreen(new CookieMenuScreen());
        });
    }

    public static final class CookieMenuScreen extends Screen {
        protected CookieMenuScreen() { super(Component.literal("Cookie Client")); }
        @Override protected void init() {
            int w = 190, x = (this.width - w) / 2, y = this.height / 4;
            addRenderableWidget(net.minecraft.client.gui.components.Button.builder(label("Fullbright", fullbright), b -> { fullbright = !fullbright; b.setMessage(label("Fullbright", fullbright)); }).bounds(x, y, w, 20).build()); y += 25;
            addRenderableWidget(net.minecraft.client.gui.components.Button.builder(label("Coordinates HUD", coordsHud), b -> { coordsHud = !coordsHud; b.setMessage(label("Coordinates HUD", coordsHud)); }).bounds(x, y, w, 20).build()); y += 25;
            addRenderableWidget(net.minecraft.client.gui.components.Button.builder(label("Armor alerts", armorAlerts), b -> { armorAlerts = !armorAlerts; b.setMessage(label("Armor alerts", armorAlerts)); }).bounds(x, y, w, 20).build()); y += 25;
            addRenderableWidget(net.minecraft.client.gui.components.Button.builder(label("Mob outlines", mobOutlines), b -> { mobOutlines = !mobOutlines; b.setMessage(label("Mob outlines", mobOutlines)); }).bounds(x, y, w, 20).build()); y += 25;
            addRenderableWidget(net.minecraft.client.gui.components.Button.builder(label("Ore highlight (private worlds)", oreHighlight), b -> { oreHighlight = !oreHighlight; b.setMessage(label("Ore highlight (private worlds)", oreHighlight)); }).bounds(x, y, w, 20).build()); y += 25;
            addRenderableWidget(net.minecraft.client.gui.components.Button.builder(label("Auto Totem (permitted worlds)", autoTotem), b -> { autoTotem = !autoTotem; b.setMessage(label("Auto Totem (permitted worlds)", autoTotem)); }).bounds(x, y, w, 20).build());
        }
        private static Component label(String name, boolean enabled) { return Component.literal(name + ": " + (enabled ? "ON" : "OFF")); }
        @Override public void render(net.minecraft.client.gui.GuiGraphics g, int mouseX, int mouseY, float delta) {
            renderBackground(g, mouseX, mouseY, delta);
            g.drawCenteredString(font, "COOKIE CLIENT", width / 2, height / 4 - 28, 0x33BBFF);
            super.render(g, mouseX, mouseY, delta);
        }
        @Override public boolean isPauseScreen() { return false; }
    }
}
